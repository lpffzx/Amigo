CREATE TRIGGER txnumseq
BEFORE INSERT ON t_money
FOR EACH ROW
  begin
         declare dt char(14);
         declare bh_id char(22);
         declare number int;
         declare new_bh varchar(22);
    
         set dt = date_format(now(),'%Y%m%d%H%i%s');
    
         select
             max(tx_num) into bh_id
         from t_money 
         where tx_num like concat('50',dt,'%');
    
         if bh_id = '' or bh_id is null then
             set new_bh = concat(dt,'00001');
         else
             set number = right(bh_id,5) + 1;
             set new_bh = right(concat('00000',number),5);
             set new_bh = concat(dt,new_bh);
         end if;
         set new.tx_num = concat('50',new_bh);
     end;
