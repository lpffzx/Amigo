CREATE TRIGGER orderserveiceseq
BEFORE INSERT ON t_order_service
FOR EACH ROW
  begin
         declare dt char(14);
         declare bh_id char(22);
         declare number int;
         declare new_bh varchar(22);
    
         set dt = date_format(now(),'%y%m%d%h%i%s');
    
         select
             max(m_num) into bh_id
         from t_order_service 
         where m_num like concat(dt,'%');
    
         if bh_id = '' or bh_id is null then
             set new_bh = concat(dt,'001');
         else
             set number = right(bh_id,3) + 1;
             set new_bh =  right(concat('000',number),3);
             set new_bh=concat(dt,new_bh);
         end if;
         set new.m_num = new_bh;
     end;
