CREATE TRIGGER ordernumseq
BEFORE INSERT ON t_order
FOR EACH ROW
  begin
         declare dt char(14);
         declare bh_id char(22);
         declare number int;
         declare new_bh varchar(22);
    
         set dt = date_format(now(),'%Y%m%d%h%i%s');
    
         select
             max(m_order_num) into bh_id
         from t_order 
         where m_order_num like concat(dt,'%');
    
         if bh_id = '' or bh_id is null then
             set new_bh = concat(dt,'00000001');
         else
             set number = right(bh_id,8) + 1;
             set new_bh =  right(concat('00000000',number),8);
             set new_bh=concat(dt,new_bh);
         end if;
         set new.m_order_num = new_bh;
         set new.m_out_refund_no = replace(uuid(),'-','');
     end;
