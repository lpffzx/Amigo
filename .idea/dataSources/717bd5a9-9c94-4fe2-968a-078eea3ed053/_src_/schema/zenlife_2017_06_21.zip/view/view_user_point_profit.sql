CREATE VIEW view_user_point_profit AS
  SELECT
    `c`.`title`                                   AS `actionName`,
    `b`.`nickname`                                AS `userName`,
    if(isnull(`e`.`m_seller_id`), '1', '2')       AS `userType`,
    if(isnull(`e`.`m_seller_id`), '普通用户', '销售代表') AS `userTypeName`,
    `a`.`id`                                      AS `id`,
    `a`.`action`                                  AS `action`,
    `a`.`create_datetime`                         AS `create_datetime`,
    `a`.`description`                             AS `description`,
    `a`.`name`                                    AS `name`,
    `a`.`period`                                  AS `period`,
    `a`.`points`                                  AS `points`,
    `a`.`rel_id`                                  AS `rel_id`,
    `a`.`title`                                   AS `title`,
    `a`.`user_id`                                 AS `user_id`,
    `a`.`platform`                                AS `platform`,
    `a`.`imei`                                    AS `imei`,
    `a`.`channel`                                 AS `channel`,
    `a`.`model`                                   AS `model`
  FROM (((`zenlife_2017_06_21`.`zl_user_behavior_config` `c`
    JOIN `zenlife_2017_06_21`.`zl_user_point` `a` ON ((`c`.`action` = `a`.`action`))) JOIN
    `zenlife_2017_06_21`.`zl_user` `b` ON (((`a`.`user_id` = `b`.`id`) AND ((`b`.`auth_type_num` & 4) > 0)))) LEFT JOIN
    `zenlife_2017_06_21`.`t_seller` `e` ON ((`a`.`user_id` = convert(`e`.`m_seller_userId` USING utf8mb4))));
